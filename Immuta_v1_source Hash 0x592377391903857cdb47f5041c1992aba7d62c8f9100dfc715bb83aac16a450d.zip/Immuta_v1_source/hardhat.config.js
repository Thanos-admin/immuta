require("@nomicfoundation/hardhat-toolbox");

module.exports = {
  solidity: {
    version: "0.8.24",
    settings: {
      evmVersion: "shanghai",
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  },
  networks: {
    pulsechainTestnet: {
      url: "https://pulsechain-testnet-rpc.publicnode.com",
      chainId: 943,
      accounts: [process.env.PRIVATE_KEY],
    },
    pulsechain: {
      url: "https://rpc.pulsechainstats.com",
      chainId: 369,
      accounts: [process.env.PRIVATE_KEY],
    },
  },
};
